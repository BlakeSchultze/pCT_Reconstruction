close all;


output_directory = 'C:\Users\Blake\Documents\Visual Studio 2010\Projects\pCT_Reconstruction\Output\';

output_folder = 'input_CTP404\';
%output_folder = 'input_CTP404\New folder (7)\\';
%output_folder = 'input_water_GeantNONUC\';

FBP_image_filename = 'FBP_image_h';
SC_image_filename = 'x_SC';
MSC_image_filename = 'x_MSC';
SM_image_filename = 'x_SM';
initial_iterate_filename = 'x_k0';
iterates_basename = 'x_';
final_image_filename = 'x';

FBP_image_path = [output_directory, output_folder, FBP_image_filename];
SC_image_path = [output_directory, output_folder, SC_image_filename];
MSC_image_path = [output_directory, output_folder, MSC_image_filename];
SM_image_path = [output_directory, output_folder, SM_image_filename];
initial_iterate_path = [output_directory, output_folder, initial_iterate_filename];
iterates_path = [output_directory, output_folder, iterates_basename];
final_image_path = [output_directory, output_folder, final_image_filename];

plot_FBP_image = false;
plot_SC_image = false;
plot_MSC_image = false;
plot_SM_image = false;
plot_initial_iterate = false;
plot_iterates = true;
plot_final_image = false;

write_FBP_image = false;
write_SC_image = false;
write_MSC_image = false;
write_SM_image = false;
write_initial_iterate = false;
write_iterates = false;
write_final_image = false;

output_image_type = 'png';
image_options = {output_image_type, 'Author', 'Me', 'Copyright', '2014', 'bitdepth', 16};

slices = 32;

FBP_IMAGE = false;
FBP = false;
SC = false;
MSC = false;
SM = false;
HULL = false;
X0 = true;
XK = true;
X = true;

start_slice = 10;
end_slice = 20;
if(plot_FBP_image)
    text_image = read_pCT_txt_image(FBP_image_path);
    text_image = mat2gray(text_image, [0,2]);
    for slice = start_slice:end_slice
        image_slice = Return_Hull_Slice( text_image, slice )
        display_text_images({image_slice}, true);
        if(write_FBP_image)
            matrix_2_image(image_slice, [FBP_image_path, '_Slice_', int2str(slice)],  image_options)
        end
    end
end

start_slice = 17;
end_slice = 17;
if(plot_initial_iterate)
	text_image = read_pCT_txt_image(initial_iterate_path);
	text_image = mat2gray(text_image, [0,2]);
	for slice = start_slice:end_slice
        image_slice = Return_Hull_Slice( text_image, slice );
        display_text_images({image_slice}, true);
        if(write_initial_iterate)
            matrix_2_image(image_slice, [FBP_image_path, '_Slice_', int2str(slice)],  image_options)
        end
	end
end

iterations = 20;
start_slice = 17;
end_slice = 17;
if(plot_iterates)
	for iteration = 1:iterations
        text_image = read_pCT_txt_image([iterates_path, int2str(iteration)]);
        text_image = mat2gray(text_image, [0,2]);
        for slice = start_slice:end_slice
            image_slice = Return_Hull_Slice( text_image, slice );
            display_text_images({image_slice}, true);
            if(write_iterates)
            matrix_2_image(image_slice, [FBP_image_path, '_Slice_', int2str(slice)],  image_options)
            end
        end
    end
end

start_slice = 17;
end_slice = 17;
if(plot_final_image)
    text_image = read_pCT_txt_image(final_image_path);
    text_image = mat2gray(text_image, [0,2]);
    for slice = 1:slices
        image_slice = Return_Hull_Slice( text_image, slice )
        display_text_images({image_slice}, true);
        if(write_final_image)
            matrix_2_image(image_slice, [FBP_image_path, '_Slice_', int2str(slice)],  image_options)
        end
    end
end