function display_text_images(images, full_screen)
    num_images = size(images, 2);
    if( full_screen )
        for i = 1 : num_images
            %set( figure, 'Name', ['Image ', num2str(i)], 'units', 'normalized', 'outerposition', [0 0 1 1] );
            figure, imshow(images{i});
            set( gcf, 'Name', ['Image ', num2str(i)], 'units', 'normalized', 'outerposition', [0 0 1 1] );
        end 
    else
        for i = 1 : num_images
         	
            figure, imshow(images{i});
            set( gcf, 'Name', ['Image ', num2str(i)]);
        end 
    end
end